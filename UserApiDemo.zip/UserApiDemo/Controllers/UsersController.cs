﻿using Microsoft.AspNetCore.Mvc;
using UserApiDemo.Models;

namespace UserApiDemo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        // Simulando banco de dados em memória
        private static List<User> Users = new List<User>()
        {
            new User { Id = 1, Name = "João", Email = "joao@example.com" },
            new User { Id = 2, Name = "Maria", Email = "maria@example.com" }
        };

        // GET api/users
        [HttpGet]
        public ActionResult<List<User>> Get()
        {
            return Ok(Users);
        }

        // GET api/users/{id}
        [HttpGet("{id}")]
        public ActionResult<User> Get(int id)
        {
            var user = Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
                return NotFound(new { message = "Usuário não encontrado" });

            return Ok(user);
        }

        // POST api/users
        [HttpPost]
        public ActionResult<User> Post([FromBody] User newUser)
        {
            newUser.Id = Users.Any() ? Users.Max(u => u.Id) + 1 : 1;
            Users.Add(newUser);
            return CreatedAtAction(nameof(Get), new { id = newUser.Id }, newUser);
        }

        // PUT api/users/{id}
        [HttpPut("{id}")]
        public ActionResult<User> Put(int id, [FromBody] User updatedUser)
        {
            var existingUser = Users.FirstOrDefault(u => u.Id == id);
            if (existingUser == null)
                return NotFound(new { message = "Usuário não encontrado" });

            existingUser.Name = updatedUser.Name;
            existingUser.Email = updatedUser.Email;

            return Ok(existingUser);
        }

        // DELETE api/users/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var user = Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
                return NotFound(new { message = "Usuário não encontrado" });

            Users.Remove(user);
            return NoContent();
        }
    }
}
